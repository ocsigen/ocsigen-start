/*
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
 */

#import <Cordova/CDVPlugin.h>

@interface CDVKeyboard : CDVPlugin {
    @protected
    BOOL _shrinkView;
    @protected
    BOOL _hideFormAccessoryBar;
    @protected
    id _keyboardShowObserver, _keyboardHideObserver, _keyboardWillShowObserver, _keyboardWillHideObserver;
    @protected
    id _shrinkViewKeyboardWillChangeFrameObserver;
}

@property (readwrite, assign) BOOL shrinkView;
@property (readwrite, assign) BOOL disableScrollingInShrinkView;
@property (readwrite, assign) BOOL hideFormAccessoryBar;
@property (readonly, assign) BOOL keyboardIsVisible;

- (void)shrinkView:(CDVInvokedUrlCommand*)command;
- (void)disableScrollingInShrinkView:(CDVInvokedUrlCommand*)command;
- (void)hideFormAccessoryBar:(CDVInvokedUrlCommand*)command;
- (void)hide:(CDVInvokedUrlCommand*)command;

@end
